<? if(!defined('IS_TEMPLATE') || IS_TEMPLATE != 'Y') die();
include($_SERVER['DOCUMENT_ROOT'].'/assets/php/controller/search.php');

?>
<div class="top_filt">
	<div class="tf_tit">подберите подходящую новостройку</div>
	<form action="[[~303]]" id="search_form" method="GET">
		<div class="tf_search">
			<div class="wr_search">
				<input type="text" name="search" placeholder="Название ЖК, застройщика, района, улицы или ключевое слово" autocomplete="off" value="<?=$_GET['search']?>">
				<input type="hidden" name="asId" value="as0">
				<button type="submit" id="gk_count">[[getCount? &parent=`43`]] новостроек</button>
				<ul id="search_suggestion" style="display:none;"></ul>
			</div>
			<?if($site_start == $curent_id):?>
				<a href="#" class="tf_clear"><img src="/assets/image/icon4.png" alt="">Очистить фильтры</a>
			<?else:?>
				<a href="#" class="tf_clear full_poisk"><img src="/assets/image/tr9.png" alt="">Показать поисковик</a>
			<?endif;?>
		</div>
		<div class="tf_cont <?if($site_start == $curent_id):?>active<?endif;?>">
			<div class="tf_row">
				<span class="tfr_tit">Количество комнат</span>
				<div class="kol_kom">
					<?foreach($arCountRooms as $arCount):?>
						<?$is_active = in_array($arCount['value'],$_GET['count_rooms']);?>
						<div class="count_rooms kk_it<?=$is_active?' active':'';?>">
							<?=$arCount['title']?>
							<input type="hidden" value="<?=$arCount['value']?>" name="count_rooms[]" <?=$is_active?'':'disabled';?>>
						</div>
					<?endforeach;?>
				</div>
				<span class="tfr_tit">Цена, руб.</span>
				<div class="fil_pr">
					<div class="fpr_it price_type<?=($price_type=='flat')?' active':'';?>" data-val="flat">
						За квартиру
					</div>
					<div class="fpr_it price_type<?=($price_type=='m2')?' active':'';?>" data-val="m2">
						м<sup><small>2</small></sup> 
					</div>
				</div>

				<input type="hidden" value="flat" name="<?=$price_type?>">
				<input type="text" class="fl_ot" placeholder="От" name="price_min" value="<?=$price_min?>" maxlength="8">
				<input type="text" class="fl_do" placeholder="До" name="price_max" value="<?=$price_max?>" maxlength="8">
			</div>
			<div class="tf_row">
				<span class="tfr_tit">Срок сдачи</span>
				<div class="kol_kom sr_sd">
					<?foreach($arYears as $arYear):?>
						<?$is_active = in_array($arYear['value'],$_GET['srok_sdachi']);?>
						<div class="kk_it srok_sdachi<?=$is_active?' active':'';?>">
							<?=$arYear['title']?>
							<input type="hidden" value="<?=$arYear['value']?>" name="srok_sdachi[]" <?=$is_active?'':'disabled';?>>
						 </div>
					<?endforeach;?>
				</div>
				<span class="tfr_tit">Площадь, м2</span>
				<input type="text" class="pl_ot" placeholder="От" name="area_min" value="<?=$area_min?>" maxlength="3">
				<input type="text" class="pl_do" placeholder="До" name="area_max" value="<?=$area_max?>" maxlength="3">
				<div class="wr_chek fl_rem">
					<input type="checkbox" class="checkbox chek_only" id="checkbox-rem" name="rem" value="1" <?=$input_rem?>>
					<label for="checkbox-rem"><span class="tfr_tit">Ремонт</span></label>
				</div>
				<div class="wr_chek">
					<input type="checkbox" class="checkbox chek_only"  id="checkbox-fz" name="fz" value="1" <?=$input_fz?>>
					<label for="checkbox-fz"><span class="tfr_tit">ФЗ-214</span></label>
				</div>
			</div>
			<div class="tf_row">
				<div class="fl_select">
					<span class="g_sel">Округ</span>
					<div class="hid_sel">
						<div class="hs_wr">
							<?foreach($arOkrug as $okrug):?>
								<?if(trim($okrug['pagetitle'])=="") continue;?>
								<div class="wr_chek">
									<input type="checkbox" class="checkbox okrug"  id="checkbox-<?=$okrug['id']?>" data-okrug_id="<?=$okrug['id']?>" name="okrug[]" value="<?=$okrug['id']?>">
									<label for="checkbox-<?=$okrug['id']?>">
										<span class="tfr_tit"><?=$okrug['pagetitle']?></span>
									</label>
								</div>
							<?endforeach;?>
						</div>
					</div>
				</div>

				<div class="fl_select">
					<span class="g_sel">Район <span id="raion_count">(0)</span></span>
					<div class="hid_sel">
						<div class="hs_wr">
							<?foreach($arRaion as $raion):?>
								<?if(trim($raion['pagetitle'])=="") continue;?>
								<div class="wr_chek chek_raion okrug_<?=$raion['parent']?> dn active">
									<input type="checkbox" class="checkbox"  id="checkbox-<?=$raion['id']?>" name="raion[]" value="<?=$raion['id']?>">
									<label for="checkbox-<?=$raion['id']?>">
										<span class="tfr_tit"><?=$raion['pagetitle']?></span>
									</label>
								</div>
							<?endforeach;?>
						</div>
					</div>
				</div>
				<div class="wr_chek fl_ipot">
					<input type="checkbox" class="checkbox chek_only" id="checkbox-ipot" name="ipot" value="1" <?=$input_ipot?>>
					<label for="checkbox-ipot"><span class="tfr_tit">Ипотека</span></label>
				</div>
				<div class="wr_chek fl_vipot">
					<input type="checkbox" class="checkbox chek_only" id="checkbox-mil_ipot" name="mil_ipot" value="1" <?=$input_mil_ipot?>>
					<label for="checkbox-mil_ipot"><span class="tfr_tit">Военная ипотека</span></label>
				</div>
				<div class="wr_chek fl_act">
					<input type="checkbox" class="checkbox chek_only" id="checkbox-akcia" name="akcia" value="1" <?=$input_akcia?>>
					<label for="checkbox-akcia"><span class="tfr_tit">Акция</span></label>
				</div>
			</div>
		</div>
	</form>
</div>
<?if($site_start != $curent_id):?>
<script>
	$(document).ready(function(){
		submitSearch();
	});
</script>
<?endif?>