<? if(!defined('IS_TEMPLATE') || IS_TEMPLATE != 'Y') die();

$arResource = array();
$arResource['id'] = $modx->resource->get('id');
$arResource['city'] = 'г.'.$modx->getOption('city', null,'');
$arResource['contacty_title'] = $modx->resource->getTVvalue('gk.contacty.title');

$modResource = $modx->getObject('modResource',$modx->resource->getTVvalue('object_okrug'));
$arResource['object_okrug'] = array(
	'id' => $modResource->get('id'),
	'pagetitle' => $modResource->get('pagetitle'),
);
$arResource['object_okrug']['url'] = $modx->runSnippet('pdoResources',array(
	'parents' => 357,
	'depth' => '0',
	'limit' => '0',
	'tvFilters' => 'fast_link.okrug=='.$arResource['object_okrug']['id'],
	'tpl' => '@INLINE [[~[[+id]]]]',
	//'showLog' => '1',
));

$modResource = $modx->getObject('modResource',$modx->resource->getTVvalue('object_raion'));
$arResource['object_raion'] = array(
	'id' => $modResource->get('id'),
	'pagetitle' => $modResource->get('pagetitle'),
);
$arResource['object_raion']['url'] = $modx->runSnippet('pdoResources',array(
	'parents' => 358,
	'depth' => '0',
	'limit' => '0',
	'tvFilters' => 'fast_link.raion=='.$arResource['object_raion']['id'],
	'tpl' => '@INLINE [[~[[+id]]]]',
	//'showLog' => '1',
));

$modResource = $modx->getObject('modResource',$modx->resource->getTVvalue('object_street'));
$arResource['object_street'] = array(
	'id' => $modResource->get('id'),
	'pagetitle' => $modResource->get('pagetitle'),
);
$arResource['object_street']['url'] = $modx->runSnippet('pdoResources',array(
	'parents' => 355,
	'depth' => '0',
	'limit' => '0',
	'tvFilters' => 'fast_link.street=='.$arResource['object_street']['id'],
	'tpl' => '@INLINE [[~[[+id]]]]',
	//'showLog' => '1',
));

unset($modResource);


$arResource['pagetitle'] = $modx->resource->get('pagetitle');
$arResource['imgs'] = json_decode($modx->resource->getTVvalue('imgs'),true);

$arResource['object_class'] = explode('||',$modx->resource->getTVvalue('object_class'));

foreach($arResource['object_class'] as $k=>$class){
	$class = array(
		'title' => $class,
	);
	$class['url'] = $modx->runSnippet('pdoResources',array(
		'parents' => 391,
		'depth' => '0',
		'limit' => '0',
		'tvFilters' => 'object_class=='.$class['title'],
		'tpl' => '@INLINE [[~[[+id]]]]',
		//'showLog' => '1',
	));
	$arResource['object_class'][$k] = $class;
}

$arResource['object_otdelka'] = explode('||',$modx->resource->getTVvalue('object_otdelka'));

foreach($arResource['object_otdelka'] as $k=>$otdelka){
	$otdelka = array(
		'title' => $otdelka,
	);
	$otdelka['url'] = $modx->runSnippet('pdoResources',array(
		'parents' => 395,
		'depth' => '0',
		'limit' => '0',
		'tvFilters' => 'object_otdelka=='.$otdelka['title'],
		'tpl' => '@INLINE [[~[[+id]]]]',
		//'showLog' => '1',
	));
	$arResource['object_otdelka'][$k] = $otdelka;
}

//Материал строительства
$arResource['object_material'] = array(
	'title' => $modx->resource->getTVvalue('object_material'),
);

$arResource['object_material']['url'] = $modx->runSnippet('pdoResources',array(
	'parents' => 397,
	'depth' => '0',
	'limit' => '0',
	'tvFilters' => 'object_material=='.$arResource['object_material']['title'],
	'tpl' => '@INLINE [[~[[+id]]]]',
	//'showLog' => '1',
));

//Закон
$arResource['object_zakon'] = array(
	'title' => $modx->resource->getTVvalue('object_zakon'),
);

$arResource['object_zakon']['url'] = $modx->runSnippet('pdoResources',array(
	'parents' => 399,
	'depth' => '0',
	'limit' => '0',
	'tvFilters' => 'object_zakon=='.$arResource['object_zakon']['title'],
	'tpl' => '@INLINE [[~[[+id]]]]',
	//'showLog' => '1',
));


//Рассрочка
$arResource['object_dop_rassrochka']['title'] = $modx->resource->getTVvalue('object_dop_rassrochka');
if($arResource['object_dop_rassrochka']['title'] == 1){
	$arResource['object_dop_rassrochka']['url'] = $modx->runSnippet('pdoResources',array(
		'parents' => 402,
		'depth' => '0',
		'limit' => '0',
		'tvFilters' => 'object_dop_rassrochka=='.$arResource['object_dop_rassrochka']['title'],
		'tpl' => '@INLINE [[~[[+id]]]]',
		//'showLog' => '1',
	));
}
//Ипотека
$arResource['object_dop_ipoteka']['title'] = $modx->resource->getTVvalue('object_dop_ipoteka');
if($arResource['object_dop_ipoteka']['title'] == 1){
	$arResource['object_dop_ipoteka']['url'] = $modx->runSnippet('pdoResources',array(
		'parents' => 402,
		'depth' => '0',
		'limit' => '0',
		'tvFilters' => 'object_dop_ipoteka=='.$arResource['object_dop_ipoteka']['title'],
		'tpl' => '@INLINE [[~[[+id]]]]',
		//'showLog' => '1',
	));
}
//Военная ипотека
$arResource['object_dop_voen_ipoteka']['title'] = $modx->resource->getTVvalue('object_dop_voen_ipoteka');
if($arResource['object_dop_voen_ipoteka']['title'] == 1){
	$arResource['object_dop_voen_ipoteka']['url'] = $modx->runSnippet('pdoResources',array(
		'parents' => 402,
		'depth' => '0',
		'limit' => '0',
		'tvFilters' => 'object_dop_voen_ipoteka=='.$arResource['object_dop_voen_ipoteka']['title'],
		'tpl' => '@INLINE [[~[[+id]]]]',
		//'showLog' => '1',
	));
}
//Материнский капитал
$arResource['object_dop_mat_kap']['title'] = $modx->resource->getTVvalue('object_dop_mat_kap');
if($arResource['object_dop_mat_kap']['title'] == 1){
	$arResource['object_dop_mat_kap']['url'] = $modx->runSnippet('pdoResources',array(
		'parents' => 402,
		'depth' => '0',
		'limit' => '0',
		'tvFilters' => 'object_dop_mat_kap=='.$arResource['object_dop_mat_kap']['title'],
		'tpl' => '@INLINE [[~[[+id]]]]',
		//'showLog' => '1',
	));
}
//Рассрочка
$arResource['object_rassrochka'] = $modx->resource->getTVvalue('object_rassrochka');
//Акция текст
$arResource['akcia']['id'] = $modx->runSnippet('pdoResources',array(
	'parents' => 265,
	'depth' => '0',
	'limit' => '0',
	'tvFilters' => 'novostroyka=='.$arResource['id'],
	'tpl' => '@INLINE [[+id]]',
	//'showLog' => '1',
));
$arResource['akcia']['content'] = substr($modx->getObject('modResource',$arResource['akcia']['id'])->get('content'),0,300).'...';


//Скидка текст
$arResource['skidka']['id'] = $modx->runSnippet('pdoResources',array(
	'parents' => 274,
	'depth' => '0',
	'limit' => '0',
	'tvFilters' => 'novostroyka=='.$arResource['id'],
	'tpl' => '@INLINE [[+id]]',
	//'showLog' => '1',
));
$arResource['skidka']['content'] = substr($modx->getObject('modResource',$arResource['akcia']['id'])->get('content'),0,300).'...';



//Документы
$arResource['docs'] = $modx->fromJSON($modx->resource->getTVvalue('gk.docs'));

//Банки
$arResource['banki'] = $modx->resource->getTVvalue('gk.banki');
$banki_id['id:IN'] = explode(',',$arResource['banki']);
$banki_html = $modx->runSnippet('pdoResources',array(
	'parents' => 290,
	'depth' => '0',
	'limit' => '0',
	'includeTVs' => 'logo',
	'where' => json_encode($banki_id),
	'tpl' => '@INLINE
		<div class="acb_item">
			<img src="[[phpthumbon? &input=`[[+tv.logo]]` &options=`&w=72&h=72&zc=1&q=100`]]" alt="">
			<div class="acb_link">
				<a href="[[~[[+id]]]]">[[+pagetitle]]</a>
			</div>
		</div>',
	//'showLog' => '1',
));

$arResource['banki'] = $banki_html;
//Другие литеры
$arResource['other_gk'] = array(
	'show'=>$modx->resource->getTVvalue('gk.other-gk.show'),
);
if($arResource['other_gk']['show']==1){
	$arResource['other_gk']['html'] = $modx->runSnippet('pdoResources',array(
		'parents' => 43,
		'depth' => '0',
		'limit' => '0',
		'includeTVs' => 'object_srok_sdachi_year,object_srok_sdachi,object_zastoyshik,object_okrug,object_raion,object_street,imgs',
		'where' => json_encode(array('id:IN'=>explode(',',$modx->resource->getTVvalue('gk.other-gk')))),
		'tpl' => 'frontNovostroyTpl',
		//'showLog' => '1',
	));
}
//Похожие новостройки по цене
$arResource['other_price'] = array(
	'show'=>$modx->resource->getTVvalue('gk.other-price.show'),
);
if($arResource['other_price']['show']==1){
	$arResource['other_price']['html'] = $modx->runSnippet('pdoResources',array(
		'parents' => 43,
		'depth' => '0',
		'limit' => '3',
		'includeTVs' => 'object_srok_sdachi_year,object_srok_sdachi,object_zastoyshik,object_okrug,object_raion,object_street,imgs',
		'where' => json_encode(array('id:IN'=>explode(',',$modx->resource->getTVvalue('gk.other-price')))),
		'tpl' => 'frontNovostroyTpl',
		//'showLog' => '1',
	));
}
//НОВОСТРОЙКИ В ЭТОМ РАЙОНЕ
$arResource['other_raion'] = array(
	'show'=>$modx->resource->getTVvalue('gk.other-raion.show'),
);
if($arResource['other_raion']['show']==1){
	$arResource['other_raion']['html'] = $modx->runSnippet('pdoResources',array(
		'parents' => 43,
		'depth' => '0',
		'limit' => '3',
		'sortby' => 'RAND()',
		'includeTVs' => 'object_srok_sdachi_year,object_srok_sdachi,object_zastoyshik,object_okrug,object_raion,object_street,imgs',
		'tvFilters' => 'object_raion=='.$modx->resource->getTVvalue('object_raion'),
		'where' => json_encode(array('id:!='=>$arResource['id'])),
		'tpl' => 'frontNovostroyTpl',
		//'showLog' => '1',
	));
	$arResource['other_raion']['total'] = $modx->getPlaceholder('total');
	$arResource['other_raion']['link'] = $modx->runSnippet('pdoResources',array(
		'parents' => 358,
		'depth' => '0',
		'limit' => '1',
		'tvFilters' => 'fast_link.raion=='.$modx->resource->getTVvalue('object_raion'),
		'tpl' => '@INLINE [[~[[+id]]]]',
		//'showLog' => '1',
	));
}
//Тип ответственного лица
// 1 - застройщик
// 2 - агент
if((int)$modx->resource->getTVvalue('object_zastoyshik') > 0 || (int)$modx->resource->getTVvalue('gk.agent') > 0){
	$arResource['face_type'] = array(
		'type'=>$modx->resource->getTVvalue('gk.ot-l.type'),
	);
	if($arResource['face_type']['type'] == 1){
		$arResource['face_type']['title'] = 'Застройщик';
		$arResource['face_type']['object'] = $modx->getObject('modResource',$modx->resource->getTVvalue('object_zastoyshik'));
		$arResource['face_type']['link'] = $modx->runSnippet('pdoResources',array(
			'parents' => 36,
			'depth' => '3',
			'limit' => '1',
			'where' => json_encode(array('id' => $arResource['face_type']['object']->get('id'))),
			'tpl' => '@INLINE [[~[[+id]]]]',
			//'showLog' => '1',
		));
	}else{
		$arResource['face_type']['title'] = 'Агент';
		$arResource['face_type']['object'] = $modx->getObject('modResource',$modx->resource->getTVvalue('gk.agent'));
		$arResource['face_type']['link'] = $modx->runSnippet('pdoResources',array(
			'parents' => 353,
			'depth' => '3',
			'limit' => '1',
			'tvFilters' => 'gk.agent=='.$arResource['face_type']['object']->get('id'),
			'tpl' => '@INLINE [[~[[+id]]]]',
			//'showLog' => '1',
		));
	}
		//название застройщика или агента
	$arResource['face_type']['pagetitle'] = $arResource['face_type']['object']->get('pagetitle');
		//вебсайт
	$arResource['face_type']['site'] = $arResource['face_type']['object']->getTVvalue('website');
		//телефон
	$arResource['face_type']['phone'] = $arResource['face_type']['object']->getTVvalue('phone');
	if($modx->resource->getTVvalue('gk.ot-l.phone')){
		$arResource['face_type']['phone'] .= '/'.$modx->resource->getTVvalue('gk.ot-l.phone');
	}
		//адрес
	$arResource['face_type']['address'] = $modx->resource->getTVvalue('gk.ot-l.address');
	if(!$arResource['face_type']['address']){
		$arResource['face_type']['address'] = $arResource['face_type']['object']->getTVvalue('zt.address');
	}
}
//Цены
$arResource['price'] = array();
$arCountRoomsTitle = array(
	0 => 'Студия',
	1 => '1-комнатные',
	2 => '2-комнатные',
	3 => '3-комнатные',
	4 => '4-комнатные',
);
foreach ($modx->resource->getIterator('Children') as $child) {
	$count_rooms = $child->getTVvalue('count_rooms');
	$price = $child->getTVvalue('flat_price');
	$price_m2 = $child->getTVvalue('flat_price_m2');
	$area = $child->getTVvalue('flat_area');
	$arResource['price'][$count_rooms]['title'] = $arCountRoomsTitle[$count_rooms];

	$arResource['price'][$count_rooms]['items'][] = array(
		'price' => $price,
		'price_m2' => $price_m2,
		'area' => $area,
		'plan' => json_decode($child->getTVvalue('imgs'),true)[0],
	);
	if((int)$arResource['price'][$count_rooms]['min_price'] > 0){
		$arResource['price'][$count_rooms]['min_price'] = min($arResource['price'][$count_rooms]['min_price'],$price);
	}else{
		$arResource['price'][$count_rooms]['min_price'] = $price;
	}
	if((int)$arResource['price'][$count_rooms]['min_price_m2'] > 0){
		$arResource['price'][$count_rooms]['min_price_m2'] = min($arResource['price'][$count_rooms]['min_price_m2'],$price_m2);
	}else{
		$arResource['price'][$count_rooms]['min_price_m2'] = $price_m2;
	}
	if((int)$arResource['price'][$count_rooms]['min_area'] > 0){
		$arResource['price'][$count_rooms]['min_area'] = min($arResource['price'][$count_rooms]['min_area'],$area);
	}else{
		$arResource['price'][$count_rooms]['min_area'] = $area;
	}
	
	
	$arResource['price'][$count_rooms]['max_price'] = max($arResource['price'][$count_rooms]['max_price'],$price);
	$arResource['price'][$count_rooms]['max_price_m2'] = max($arResource['price'][$count_rooms]['max_price_m2'],$price_m2);
	$arResource['price'][$count_rooms]['max_area'] = max($arResource['price'][$count_rooms]['max_area'],$area);
	
	
}
unset($child);


/*$arResource['balloon_html'] = $modx->runSnippet('pdoResources',array(
	'parents' => 43,
	'depth' => '0',
	'limit' => '1',
	'includeTVs' => 'object_srok_sdachi_year,object_srok_sdachi,object_zastoyshik,object_okrug,object_raion,object_street,imgs',
	'where' => json_encode(array('id'=>$arResource['id'])),
	'tpl' => 'frontNovostroyTpl',
	//'showLog' => '1',
));

$arResource['balloon_html'] = '<div class="nov_item">
	<div class="ni_img">
        <img src="/assets/cache_image/assets/content/news/demo4_221x149_268.jpg" alt="" title="">
		<div class="ni_btns"><a href="#" class="ni_vid"><span>2</span></a>			
			<a href="#" class="ni_com"><span>44</span></a>
		</div>
	</div>
	<div class="ni_cont">
		<div class="ni_tit">
			<a href="новостройки/жк-новый-дом/">ЖК “ЖК Новый Дом”</a>
			<span class="ni_date">Сдан - 2 полугодие 2018 г.</span>
			<div class="like_btn"><span>Добавить в избранное</span></div>
		</div>
		<div class="ni_row">
			<strong>Застройщик:</strong> Пилигрим
		</div>
		<div class="ni_row">
			<strong>Адрес:</strong> г. Краснодар, Центральный округ, Район Черемушки, Абрикосовая
		</div>
		
		<div class="ni_row2">
			<div class="ni_ot">от <span>1 758 258</span> руб. </div>
			<div class="ni_do">от <span>45 850</span> руб. </div>
		</div>
		
		<a href="новостройки/жк-новый-дом/" class="ni_more">Подробнее</a>
	</div>
</div>';

$arResource['yandexMaps'] = $modx->runSnippet('yandexMaps',array(
	'id' => $arResource['id'],
	'tvCoords' => 'map',
	'htmlForBalloonContent' => $arResource['balloon_html'],
	'fieldForHint' => 'pagetitle',
	'showMoreLink' => 'true',
	'styleMapBlock' => 'float:left; width:100%; height:100%;',
	'zoom' => '14',
));*/

 










