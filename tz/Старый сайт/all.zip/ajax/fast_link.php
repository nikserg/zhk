<? if(!defined('FAST_LINK') || FAST_LINK != 'Y') die();

$tvFilters = array();

//�����
$object_okrug = (int)$modx->resource->getTVValue('fast_link.okrug');
if($object_okrug != 0){
	$tvFilters[] = 'object_okrug=='.$object_okrug;
}
//�����
$object_raion = (int)$modx->resource->getTVValue('fast_link.raion');
if($object_raion != 0){
	$tvFilters[] = 'object_raion=='.$object_raion;
}
//�����
$object_street = (int)$modx->resource->getTVValue('fast_link.street');
if($object_street != 0){
	$tvFilters[] = 'object_street=='.$object_street;
}
//����������
$zastroi= (int)$modx->resource->getTVValue('object_zastoyshik');
if($zastroi != 0){
	$tvFilters[] = 'object_zastoyshik=='.$zastroi;
}
//�������
$object_dop_ipoteka= (int)$modx->resource->getTVValue('object_dop_ipoteka');
if($object_dop_ipoteka != 0){
	$tvFilters[] = 'object_dop_ipoteka=='.$object_dop_ipoteka;
}
//����������� �������
$object_dop_mat_kap= (int)$modx->resource->getTVValue('object_dop_mat_kap');
if($object_dop_mat_kap != 0){
	$tvFilters[] = 'object_dop_mat_kap=='.$object_dop_mat_kap;
}
//������� �������
$object_dop_voen_ipoteka= (int)$modx->resource->getTVValue('object_dop_voen_ipoteka');
if($object_dop_voen_ipoteka != 0){
	$tvFilters[] = 'object_dop_voen_ipoteka=='.$object_dop_voen_ipoteka;
}
//���������
$object_dop_rassrochka= (int)$modx->resource->getTVValue('object_dop_rassrochka');
if($object_dop_rassrochka != 0){
	$tvFilters[] = 'object_dop_rassrochka=='.$object_dop_rassrochka;
}
//�����
$object_zakon= (int)$modx->resource->getTVValue('object_zakon');
if($object_zakon != 0){
	$tvFilters[] = 'object_zakon=='.$object_zakon;
}
//�����
$object_class = $modx->resource->getTVValue('object_class');
if($object_class && $object_class != '--'){
	$tvFilters[] = 'object_class==%'.$object_class.'%';
}
//��������
$object_material = $modx->resource->getTVValue('object_material');
if($object_material && $object_material != '--'){
	$tvFilters[] = 'object_material=='.$object_material;
}
//�������
$object_otdelka = $modx->resource->getTVValue('object_otdelka');
if($object_otdelka && $object_otdelka != '--'){
	$tvFilters[] = 'object_otdelka==%'.$object_otdelka.'%';
}

$output = $modx->runSnippet('pdoPage',array(
	'parents' => 43,
	'depth' => '0',
	'limit' => '5',
	'page' => (int)$_GET['page'],
	'includeTVs' => 'object_srok_sdachi_year,object_srok_sdachi,object_zastoyshik,object_okrug,object_raion,object_street,imgs',
	'tvFilters' => implode(',',$tvFilters),
	'tpl' => 'frontNovostroyTpl',
	'tplPageWrapper' => '@INLINE <div class="pagi_cont">[[+pages]]</div>',
	'tplPage' => '@INLINE <a href="[[+href]]">[[+pageNo]]</a>',
	'tplPageActive' => '@INLINE <a href="[[+href]]" class="active">[[+pageNo]]</a>',
	'tplPageNext' => '@INLINE <a href="[[+href]]">C�������� �������� <img src="/assets/image/tr10.png" alt=""></a>',
));
                                       

echo $output;