<? if(!defined('ACTION_AJAX') || ACTION_AJAX != 'Y') die();
include('filter_props.php');
include('prologTextSearch.php');

$tvFilters = $where = array();

//Количество комнат, 0 - Студия
if(isset($_REQUEST['count_rooms'])){
	$count_rooms_filter = array();
	foreach($_REQUEST['count_rooms'] as $count_rooms){
		if(in_array($count_rooms,$arFilterProps['count_rooms'])){
			$count_rooms_filter[] = (int)$count_rooms;
		}
	}
	//что бы в запрос попало тв поле его надо добавить в tvFilters только потом в where иначе будет ошибка
	$tvFilters[] = 'count_rooms==%';
	$whereTVcount_rooms = array('TVcount_rooms.value:IN'=>$count_rooms_filter);
	$where[] = $whereTVcount_rooms;
}

//Тип цены, если m2 - цена за м2, если нет, то за квартиру
if($_REQUEST['price_type'] == 'm2'){
	$price_type = 'flat_price_m2';
}
else{
	$price_type = 'flat_price';
}

//Границы цены, зависит от типа цены
if(isset($_REQUEST['price_min']) && !empty($_REQUEST['price_min'])){
	$price_min = str_replace(' ','',(int)$_REQUEST['price_min']);
	$tvFilters[] = $price_type.'>='.$price_min;
}

if(isset($_REQUEST['price_max']) && !empty($_REQUEST['price_max'])){
	$price_max = str_replace(' ','',(int)$_REQUEST['price_max']);
	$tvFilters[] = $price_type.'<='.$price_max;
}

//Границы площади
if(isset($_REQUEST['area_min']) && !empty($_REQUEST['area_min'])){
	$area_min = str_replace(' ','',(int)$_REQUEST['area_min']);
	$tvFilters[] = 'flat_area>='.$area_min;
}

if(isset($_REQUEST['area_max']) && !empty($_REQUEST['area_max'])){
	$area_max = str_replace(' ','',(int)$_REQUEST['area_max']);
	$tvFilters[] = 'flat_area<='.$area_max;
}

$arPreResult = $modx->runSnippet('pdoResources',array(
	'parents' => 43,
	'depth' => '1',
	'limit' => '0',
	'tvFilters' => implode('&&',$tvFilters),
	'tvFiltersAndDelimiter' => '&&',
	'where' => json_encode($where),
	'tpl' => '@INLINE[[+parent]]',
	'outputSeparator' => ','
));

$tvFilters = $where = array();
//Ремонт
if((int)$_REQUEST['rem']==1){
	$tvFilters[] = 'object_dop_rem==1';
}
//ФЗ-214
if((int)$_REQUEST['fz']==1){
	$tvFilters[] = 'object_zakon==214';
}
//Ипотека
if((int)$_REQUEST['ipot']==1){
	$tvFilters[] = 'object_dop_ipoteka==1';
}
//Военная ипотека
if((int)$_REQUEST['mil_ipot']==1){
	$tvFilters[] = 'object_dop_voen_ipoteka==1';
}
//Акция
if((int)$_REQUEST['akcia']==1){
	$tvFilters[] = 'object_dop_akcia==1';
}
//Округ
if(isset($_REQUEST['okrug'])){
	$okrug_filter = array();
	foreach($_REQUEST['okrug'] as $okrug_id){
		$okrug_filter[] = (int)$okrug_id;
	}
	$tvFilters[] = 'object_okrug==%';
	$whereTVokrug = array('TVobject_okrug.value:IN'=>$okrug_filter);
	$where[] = $whereTVokrug;
}
//Район
if(isset($_REQUEST['raion'])){
	$raion_filter = array();
	foreach($_REQUEST['raion'] as $raion_id){
		$raion_filter[] = (int)$raion_id;
	}
	$tvFilters[] = 'object_raion==%';
	$whereTVraion = array('TVobject_raion.value:IN'=>$raion_filter);
	$where[] = $whereTVraion;
}

//Срок сдачи, 2000 - сдан, 3000 - больше либо равно значению текущего года +3, например для 2016 это 2019+
if(isset($_REQUEST['srok_sdachi'])){
	$srok_sdachi_filter = array();
	$isHasMin = false;
	$isHasMax = false;
	
	foreach($_REQUEST['srok_sdachi'] as $srok_sdachi){
		if(in_array($srok_sdachi,$arFilterProps['object_srok_sdachi_year'])){
			$srok_sdachi_filter[] = (int)$srok_sdachi;
		}
		if((int)$srok_sdachi == 2000){
			$isHasMin = true;
		}
		if((int)$srok_sdachi == 3000){
			$isHasMax = true;
		}
	}
	//что бы в запрос попало тв поле его надо добавить в tvFilters только потом в where иначе будет ошибка
	$tvFilters[] = 'object_srok_sdachi_year==%';
	$prfixOR = '';
	if(!empty($srok_sdachi_filter)){
		$whereTVsrok_sdachi = array('TVobject_srok_sdachi_year.value:IN' => $srok_sdachi_filter);
		$prfixOR = 'OR:';
	}
	if($isHasMin){
		$whereTVsrok_sdachi[$prfixOR.'TVobject_srok_sdachi_year.value:<='] = (int)date('Y')-1;
		$prfixOR = 'OR:';
	}
	if($isHasMax){
		$whereTVsrok_sdachi[$prfixOR.'TVobject_srok_sdachi_year.value:>='] = (int)date('Y')+3;
	}
	$where[] = $whereTVsrok_sdachi;
}

$where['AND:id:IN'] = array_unique(explode(',',$arPreResult));
if(!empty($_REQUEST['search'])){//если введен запрос
	if($search_type == 'zastroi'){
		$tvFilters[] = 'object_zastoyshik==%';
		$where['AND:TVobject_zastoyshik.value:IN'] = $arResultZastroiId;
	}elseif($search_type == 'loc'){
		$tvFilters[] = 'object_street==%';
		$whereLOC['TVobject_street.value:IN'] = $arResultLocId;
		$tvFilters[] = 'object_raion==%';
		$whereLOC['OR:TVobject_raion.value:IN'] = $arResultLocId;
		$tvFilters[] = 'object_okrug==%';
		$whereLOC['OR:TVobject_okrug.value:IN'] = $arResultLocId;
		
		$where = array($where,$whereLOC);
	}else{
		$where['AND:id:IN'] = $arResultId;
	}
}
