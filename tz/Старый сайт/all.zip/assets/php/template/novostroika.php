<? if(!defined('IS_TEMPLATE') || IS_TEMPLATE != 'Y') die();
include($_SERVER['DOCUMENT_ROOT'].'/assets/php/controller/novostroika.php');

?>
<div class="cent_cont ">
	[[$breadcrumbs]]
	<div class="info_block ">
		<div class="gen_tit jk_bl">
			<span>ЖК “<?=$arResource['pagetitle']?>”: </span>
			<div class="gt_men"><a href="#">Описание</a></div>
			<div class="gt_men"><a href="#">Цены</a></div>
			<div class="gt_men"><a href="#">Планировки</a></div>
			<div class="gt_men"><a href="#"><?=$arResource['contacty_title']?></a></div>
			<div class="print_icon">
				<a href="javascript:window.print();void 0;"><img src="/assets/image/print_icon.png" alt=""></a>
				<span>Печать</span>
			</div>
			<div class="like_icon">
				<div class="like_btn"><span>Добавить в избранное</span></div>
			</div>
		</div>
		<div class="dop_info">
			<div class="di_adr">
				<img src="/assets/image/h_icon1.png" alt="">
				<strong>Адрес:</strong>
				<span>
					<?=$arResource['city']?>,
					<a href="<?=$arResource['object_okrug']['url']?>"><?=$arResource['object_okrug']['pagetitle']?>,</a>
					<a href="<?=$arResource['object_raion']['url']?>"><?=$arResource['object_raion']['pagetitle']?>,</a>
					<a href="<?=$arResource['object_street']['url']?>"><?=$arResource['object_street']['pagetitle']?></a>
				</span>
			</div>
			<div class="di_map gomod" modal="6">
				<img src="/assets/image/di_map.png" alt=""><span>Смотреть на карте</span>
			</div>
			<div class="gt_err">
				<img src="/assets/image/err_icon.png" alt="">
				<a href="#" class="gomod" data-formid="#err_form">Сообщить об ошибке</a>
			</div>
		</div>
		<div class="jk_ref">(обновлено [[*editedon:strtotime:date=`%d.%m.%Y`]])</div>
		<div class="jk_tab">
			<div class="jk_menu">
				<div class="jkm_it active">фото</div>
				<div class="jkm_it">видео</div>
				<div class="jkm_it">камера</div>
				<div class="jkm_it">этапы строительства</div>
				<div class="jkm_it">360 панорама</div>
			</div>
			<div class="jkt_cont active">
				<div class="map_modal topmod" modal="6">
					<div class="closmod"></div>
					[[yandexMaps?
						&id=`[[*id]]`
						&tvCoords=`map`
						&fieldForBalloonContent=`pagetitle`
						&fieldForHint=`pagetitle`
						&showMoreLink=`true`
						&styleMapBlock=`float:left; width:100%; height:100%;`
						&zoom=`14`
					]]
				</div>
				<div class="fotorama" data-nav="thumbs" data-thumbwidth="109" data-thumbheight="68" data-width="100%" data-ratio="">
					[[getImageList? &tvname=`imgs` &tpl=`novostroyPagePhotos`]]
				</div>
			</div>
			<div class="jkt_cont">
				[[getResources? &parents=`284`&tvFilters=`novostroyka==[[*id]]`&tpl=`video`&includeTVs=`video`]]
			</div>
			<div class="jkt_cont">
				[[*gk.kamera]]
			</div>
			<div class="jkt_cont">
				<div class="fotorama" data-nav="thumbs" data-thumbwidth="109" data-thumbheight="68" data-width="100%" data-ratio="">
					[[getImageList? &tvname=`gk.etapy` &tpl=`novostroyPagePhotos`]]
				</div>
			</div>
			<div class="jkt_cont">
				[[getResources? &parents=`279`&tvFilters=`novostroyka==[[*id]]`&tpl=`panorama`&includeTVs=`panorama`]]
			</div>
		</div>
		<div class="kont_bl">
			<div class="kb_col1">
				<?if($arResource['face_type']['type']):?>
					<div class="gen_tit">
						<div class="gt_img">
							<img src="/assets/image/tit_icon13.png" alt="">
						</div>
						<span><?=$arResource['contacty_title']?></span>
					</div>
					<div class="pt15">
						<?if($arResource['face_type']['type'] == 1):?>
						<div class="kb_row">
							<div class="kbr_img">
								<img src="/assets/image/kb_icon1.png" alt="">
							</div>
							<div class="kb_lb"><?=$arResource['face_type']['title']?>:</div>
							<div class="kb_in">
								<?if($arResource['face_type']['link']):?>
									<a target="_blanck" href="<?=$arResource['face_type']['link']?>"><?=$arResource['face_type']['pagetitle']?></a>
								<?else:?>
									<?=$arResource['face_type']['pagetitle']?>
								<?endif;?>
							</div>
						</div>
						<?endif;?>
						<div class="kb_row">
							<div class="kbr_img">
								<img src="/assets/image/kb_icon2.png" alt="">
							</div>
							<div class="kb_lb">Веб сайт:</div>
							<div class="kb_in"><a href="//<?=$arResource['face_type']['site']?>" rel="nofollow"><?=$arResource['face_type']['site']?></a></div>
						</div>
						<div class="kb_row">
							<div class="kbr_img">
								<img src="/assets/image/kb_icon3.png" alt="">
							</div>
							<div class="kb_lb">Телефон:</div>
							<div class="kb_in"><?=$arResource['face_type']['phone']?></div>
						</div>
						<?if($arResource['face_type']['address']):?>
						<div class="kb_row">
							<div class="kbr_img">
								<img src="/assets/image/kb_icon4.png" alt="">
							</div>
							<div class="kb_lb">Адрес:</div>
							<div class="kb_in"><?=$arResource['face_type']['address']?></div>
						</div>
						<?endif;?>
						<script src="//yastatic.net/es5-shims/0.0.2/es5-shims.min.js"></script>
						<script src="//yastatic.net/share2/share.js"></script>
						<div class="kb_row" id="ya-share">
							<div class="kb_lb">Поделиться:</div>
							<div class="kb_in">
								<div class="ya-share2" data-services="facebook,vkontakte,odnoklassniki"></div>
							</div>
						</div>
					</div>
				<?endif;?>
			</div>
			<div class="kb_col2">
				<div class="gen_tit">
					<div class="gt_img">
						<img src="/assets/image/tit_icon14.png" alt="">
					</div>
					<span>написать сообщение</span>
				</div>
				<div class="kb_form">
					<form action="/ajax/mail/gk_mail.php" method="POST" class="ajax">
						<div class="kb_row2">
							<div class="kbr_lb">Ф.И.О.: </div>
							<input type="text" name="name">
							<div class="text_err text_err-name"></div>
						</div>
						<div class="kb_row2">
							<div class="kbr_lb">E-mail:</div>
							<input type="text" name="email">
							<div class="text_err text_err-email"></div>
						</div>
						<div class="kb_row2">
							<div class="kbr_lb">Телефон: </div>
							<input type="text" name="phone">
							<div class="text_err text_err-phone"></div>
						</div>
						<div class="kb_row2">
							<div class="kbr_lb">Текст:</div>
							<textarea name="msg"></textarea>
							<div class="text_err text_err-msg"></div>
						</div>
						<div class="dn_row2 kb_row3">
							<div class="wr3_hl">
								<div class="cap4a"><img src="/assets/image/cap4a.jpg"></div>
								<input type="text" class="kapin">
							</div>
							<input type="hidden" name="id" value="<?=$arResource['id']?>">
							<input type="submit" value="Отправить">
						</div>
						<div class="kb_row3">
							<a href="#" class="dn_ref">Обновить</a>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="ab_block mt10">
			<div class="jk_ab">
				<div class="jk_col1">
					<div class="gen_tit">
						<div class="gt_img">
							<img src="/assets/image/tit_icon18.png" alt="">
						</div>
						<span>описание жк</span>
					</div>
					<div class="jkc1_cont">
						[[*content]]
					</div>
				</div>
				<div class="jk_col2">
					<div class="gen_tit">
						<div class="gt_img">
							<img src="/assets/image/tit_icon19.png" alt="">
						</div>
						<span>характеристики</span>
					</div>
					<div class="jkc2_cont">
						<table>
							<tr>
								<td>Срок сдачи</td>
								<td>[[*object_srok_sdachi]] полугодие [[*object_srok_sdachi_year]] г.</td>
							</tr>
							<?if(!empty($arResource['object_class'])):?>
							<tr>
								<td>Класс</td>
								<td>
								<?foreach($arResource['object_class'] as $k=>$class):?>
									<?if($class['url']):?>
										<a href="<?=$class['url']?>"><?=$class['title']?></a><?=($k!=count($arResource['object_class'])-1)?',':'';?>
									<?else:?>
										<?=$class['title']?><?=($k!=count($arResource['object_class'])-1)?',':'';?>
									<?endif;?>
								<?endforeach;?>
								</td>
							</tr>
							<?endif;?>
							<?if(!empty($arResource['object_otdelka'])):?>
							<tr>
								<td>Отделка</td>
								<td>
								<?foreach($arResource['object_otdelka'] as $k=>$otdelka):?>
									<?if($otdelka['url']):?>
										<a href="<?=$otdelka['url']?>"><?=$otdelka['title']?></a><?=($k!=count($arResource['object_otdelka'])-1)?',':'';?>
									<?else:?>
										<?=$otdelka['title']?><?=($k!=count($arResource['object_otdelka'])-1)?',':'';?>
									<?endif;?>
								<?endforeach;?>
								</td>
							</tr>
							<?endif;?>
							<?if(!empty($arResource['object_material'])):?>
							<tr>
								<td>Материал строительства</td>
								<td>
									<?if($arResource['object_material']['url']):?>
										<a href="<?=$arResource['object_material']['url']?>"><?=$arResource['object_material']['title']?></a>
									<?else:?>
										<?=$arResource['object_material']['title']?>
									<?endif;?>
								</td>
							</tr>
							<?endif;?>
							[[*object_etag:!empty=`
							<tr>
								<td>Этажность</td>
								<td>[[*object_etag]]</td>
							</tr>
							`]]
							[[*object_potolok:!empty=`
							<tr>
								<td>Высота потолков, м</td>
								<td>[[*object_potolok]] м</td>
							</tr>
							`]]
							<?if(!empty($arResource['object_zakon'])):?>
							<tr>
								<td>Закон, ф3</td>
								<td>
									<?if($arResource['object_zakon']['url']):?>
										<a href="<?=$arResource['object_zakon']['url']?>"><?=$arResource['object_zakon']['title']?></a>
									<?else:?>
										<?=$arResource['object_zakon']['title']?>
									<?endif;?>
								</td>
							</tr>
							<?endif;?>
							<?if($arResource['object_dop_rassrochka']['url']):?>
								<tr>
									<td>Рассрочка</td>
									<td><a href="<?=$arResource['object_dop_rassrochka']['url']?>">Да</a></td>
								</tr>
							<?endif;?>
							<?if($arResource['object_dop_ipoteka']['url']):?>
								<tr>
									<td>Ипотека</td>
									<td><a href="<?=$arResource['object_dop_ipoteka']['url']?>">Да</a></td>
								</tr>
							<?endif;?>
							<?if($arResource['object_dop_voen_ipoteka']['url']):?>
								<tr>
									<td>Военная ипотека</td>
									<td><a href="<?=$arResource['object_dop_voen_ipoteka']['url']?>">Да</a></td>
								</tr>
							<?endif;?>
							<?if($arResource['object_dop_mat_kap']['url']):?>
								<tr>
									<td>Материнский капитал</td>
									<td><a href="<?=$arResource['object_dop_mat_kap']['url']?>">Да</a></td>
								</tr>
							<?endif;?>							
						</table>
					</div>
				</div>
			</div>
		</div>

		<div class="info_block pt20">
			<div class="gen_tit">
				<div class="gt_img">
					<img src="/assets/image/tit_icon16.png" alt="">
				</div>
				<span>Цены</span>
				<div class="gt_err">
					<img src="/assets/image/err_icon.png" alt="">
					<a href="#"  data-formid="#err_form">Сообщить об ошибке</a>
				</div>
			</div>
			<div class="pr_cont">
				<table class="pr_table">
					<tbody><tr>
						<th>ТИП КВАРТИРЫ</th>
						<th>S, м2</th>
						<th>ЦЕНА за м2,руб.</th>
						<th>СТОИМОСТЬ, руб.</th>
						<th>ПЛАНИРОВКА</th>
					</tr>
					<?foreach($arResource['price'] as $k=>$arPrice):?>
						<tr>
							<td><?=$arPrice['title']?></td>
							<?if($arPrice['min_area'] != $arPrice['max_area']):?>
								<td><?=number_format($arPrice['min_area'],0,'',' ')?>-<?=number_format($arPrice['max_area'],0,'',' ')?></td>
							<?else:?>
								<td><?=number_format($arPrice['min_area'],0,'',' ')?></td>
							<?endif?>
							<?if($arPrice['min_price_m2'] != $arPrice['max_price_m2']):?>
								<td><?=number_format($arPrice['min_price_m2'],0,'',' ')?>-<?=number_format($arPrice['max_price_m2'],0,'',' ')?></td>
							<?else:?>
								<td><?=number_format($arPrice['min_price_m2'],0,'',' ')?></td>
							<?endif?>
							<?if($arPrice['min_price'] != $arPrice['max_price']):?>
								<td><?=number_format($arPrice['min_price'],0,'',' ')?>-<?=number_format($arPrice['max_price'],0,'',' ')?></td>
							<?else:?>
								<td><?=number_format($arPrice['min_price'],0,'',' ')?></td>
							<?endif?>
							<td></td>
						</tr>
						<?foreach($arPrice['items'] as $arItem):?>
							<tr class="par_row" tab="<?=$k?>">
								<td></td>
								<td><?=number_format($arItem['area'],0,'',' ')?></td>
								<td><?=number_format($arItem['price_m2'],0,'',' ')?></td>
								<td><?=number_format($arItem['price'],0,'',' ')?></td>
								<td>
								<?if($arItem['plan']['image']):?>
								<a href="/assets/content/news/<?=$arItem['plan']['image']?>" class="zoom"><img src="/assets/image/plan_img.png" alt="<?=$arItem['plan']['alt']?>" title="<?=$arItem['plan']['title']?>"></a>
								<?endif;?>
								</td>
							</tr>
						<?endforeach;?>
						<tr>
							<td colspan="5"><span class="sv_tab" tab="<?=$k?>"></span></td>
						</tr>
					<?endforeach;?>
				</tbody></table>
			</div>
		</div>
		
		<div class="ab_block">
			<div class="jk_ab jk_ab2">
				<div class="gen_tit">
					<div class="gt_img">
						<img src="/assets/image/tit_icon20.png" alt="">
					</div>
					<span>условия покупки</span>
				</div>
				<div class="jka jka1">
					<p>
						<img src="/assets/image/jk_icon1.png" alt="">
						<?if($arResource['object_rassrochka']):?>
						<strong>Рассрочка:</strong> <?=$arResource['object_rassrochka']?>
						<?endif;?>
					</p>
				</div>
				<div class="jka jka2">
					<p>
						<img src="/assets/image/jk_icon2.png" alt="">
						<strong>Акция:</strong><?=$arResource['akcia']['content']?>  <a href="<?=$modx->makeUrl($arResource['akcia']['id'])?>" class="jk_more">Подробнее</a>
					</p>
				</div>
				<div class="jka jka3">
					<p>
						<img src="/assets/image/jk_icon3.png" alt="">
						<strong>Скидка:</strong><?=$arResource['skidka']['content']?>  <a href="<?=$modx->makeUrl($arResource['skidka']['id'])?>" class="jk_more">Подробнее</a>
					</p>
				</div>
			</div>
		</div>
		<div class="info_block lb pt20">
			<div class="gen_tit">
				<div class="gt_img">
					<img src="/assets/image/tit_icon21.png" alt="">
				</div>
				<span>планировки жк “<?=$arResource['pagetitle']?>”</span>
			</div>
			<div class="plan_sl">
				<div class="psl">
					[[getImageList? &tvname=`gk.plany` &tpl=`planList`]]
				</div>
			</div>
		</div>
		<div class="dop_bl1 pt20 lb">
			<div class="dpbc1">
				<div class="gen_tit">
					<div class="gt_img">
						<img src="/assets/image/tit_icon22.png" alt="">
					</div>
					<span>документы</span>
				</div>
				<div class="doc_items pt20">
					<?foreach($arResource['docs'] as $doc):?>
					<div class="doc_item">
						<a href="/docs/<?=$doc["doc"]?>"><?=$doc["title"]?></a>
					</div>
					<?endforeach;?>
				</div>
				<div class="acb_more">
					<a href="javascript:">Показать еще</a>
				</div>
			</div>
			<div class="dpbc2 ">
				<div class="gen_tit">
					<div class="gt_img">
						<img src="/assets/image/tit_icon23.png" alt="">
					</div>
					<span>аккредитован в банках</span>
				</div>
				<div class="acb_items pt20">
					<?=$arResource['banki']?>
				</div>
				<div class="acb_more">
					<a href="javascript:">Показать еще</a>
				</div>
			</div>
		</div>
		<?if($arResource['other_gk']['show']==1):?>
		<div class="info_block pt20">
			<div class="gen_tit">
				<div class="gt_img">
					<img src="/assets/image/tit_icon24.png" alt="">
				</div>
				<span>другие литеры</span>
			</div>
			<div class="novostroiki">
				<?=$arResource['other_gk']['html']?>
			</div>
			<a href="#" class="all_items">Смотреть еще литеры</a>
		</div>
		<?endif;?>
		<?/*[[!TicketComments?
			&thread=`[[*id]]`
			&allowGuest=`1`
		]]*/?>
		<div class="info_block pt10 lb">
			<div class="gen_tit">
				<div class="gt_img">
					<img src="/assets/image/tit_icon17.png" alt="">
				</div>
				<span>отзывы о жк “Паралели”</span>

			</div>
			<div class="comments">
				<div class="comm_block comm_tree">
					<div class="com_par">
						<div class="com_img"><img src="/assets/image/comm_img.png" alt=""></div>
						<div class="com_cont">
							<div class="com_tit">
								<div class="com_name">Денис Парфимов</div>
								<div class="com_date">4 Сентября, 2012</div>
							</div>
							<div class="com_text">
								Огромное спасибо Ане Куценко и складу, молодцы вы! Упаковали груз в этот раз отлично, заплатила копейки за доставку. Ань, мы теперь поняли другу друга, я рада. Вещички супер, торгуем, одеваем деток в лагеря пионерские. Пока по следующей заявке не могу сказать точно, посмотрим, как поторгуем.
								<div class="comm_hide active">
									Огромное спасибо Ане Куценко и складу, молодцы вы! Упаковали груз в этот раз отлично, заплатила копейки за доставку. Ань, мы теперь поняли другу друга, я рада. Вещички супер, торгуем, одеваем деток в лагеря пионерские. Пока по следующей заявке не могу сказать точно, посмотрим, как поторгуем.
								</div>
							</div>
							<div class="com_more">
								<div class="comm_tab">
									<div class="comm_col1"></div>
									<div class="comm_col2"><a href="#" class="com_read active"></a></div>
								</div>
							</div>
						</div>
					</div>
					<div class="com_child">
						<div class="com_img"><img src="/assets/image/comm_img2.png" alt=""></div>
						<div class="comc_cont">
							<div class="com_tit">
								<div class="com_name">ЖК “Паралели”</div>
								<div class="com_date">4 Сентября, 2012</div>
							</div>
							<div class="comc_text">
								Большое спасибо!  <br>
								Приятно,  что  у нас получилось подобрать именно то, что Вы хотели!
							</div>
							<div class="comc_komm">
								<a href="#">Комментировать</a>
							</div>
						</div>
					</div>
				</div>

				<div class="comm_block ">
					<div class="com_par">
						<div class="com_img"><img src="/assets/image/comm_img3.png" alt=""></div>
						<div class="com_cont">
							<div class="com_tit">
								<div class="com_name">Денис Парфимов</div>
								<div class="com_date">4 Сентября, 2012</div>
							</div>
							<div class="com_text">
								Огромное спасибо Ане Куценко и складу, молодцы вы! Упаковали груз в этот раз отлично, заплатила копейки за доставку. Ань, мы теперь поняли другу друга, я рада. Вещички супер, торгуем, одеваем деток в лагеря пионерские. Пока по следующей заявке не могу сказать точно, посмотрим, как поторгуем.
								<div class="comm_hide">
									Огромное спасибо Ане Куценко и складу, молодцы вы! Упаковали груз в этот раз отлично, заплатила копейки за доставку. Ань, мы теперь поняли другу друга, я рада. Вещички супер, торгуем, одеваем деток в лагеря пионерские. Пока по следующей заявке не могу сказать точно, посмотрим, как поторгуем.
								</div>
							</div>
							<div class="com_more">
								<div class="comm_tab">
									<div class="comm_col1"><a href="#">Ответить</a></div>
									<div class="comm_col2"><a href="#" class="com_read"></a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="dob_otz">
					<div class="otziv_modal topmod" modal="4">
						<div class="closmod"></div>
						<div class="wm_tit">
							написать отзыв
						</div>
						<div class="wm_cont">
							<div class="wm_forwm">
								<div class="wm_row">
									<div class="wm_label">Имя:</div>
									<input type="text">
								</div>
								<div class="wm_row">
									<div class="wm_label">Почта:</div>
									<input type="text">
								</div>
								<div class="wm_row">
									<div class="wm_label">Текст:</div>
									<textarea></textarea>
								</div>
								<div class="wm_row3">
									<div class="wmr3_col">
										<div class="wr3_hl">
											<div class="cap4a"><img src="/assets/image/cap4a.jpg"></div>
											<input type="text" class="kapin">
										</div>
										<a href="#" class="kapref">Обновить</a>
									</div>
									<div class="wmr3_col">
										<input type="submit" value="Добавить отзыв">
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="otziv_modal topmod" modal="5">
						<div class="closmod"></div>
						<div class="wm_tit">
							написать отзыв
						</div>
						<div class="wm_cont">
							<div class="wmc_t">
								Отзывы могут оставлять <br>
								только авторизованные пользователи.
							</div>
							<div class="wmc_t2">
								<a href="#">Авторизуйтесь</a>  или  <a href="#">Зарегистрируйтесь</a>
							</div>
						</div>
					</div>

					<a href="#" class="gomod" modal="4">Добавить отзыв</a>
					<a href="#" class="gomod" modal="5" style="margin-left:20px;">Показать все отзывы</a>
				</div>
			</div>

		</div>

		<?if($arResource['other_price']['show']==1):?>
		<div class="info_block pt20 lb">
			<div class="gen_tit">
				<div class="gt_img">
					<img src="/assets/image/tit_icon25.png" alt="">
				</div>
				<span>новостройки похожие по цене</span>
			</div>
			<div class="novostroiki">
				<?=$arResource['other_price']['html']?>
			</div>
		</div>
		<?endif;?>
		<?if($arResource['other_raion']['show']==1):?>
		<div class="info_block pt20">
			<div class="gen_tit">
				<div class="gt_img">
					<img src="/assets/image/tit_icon12.png" alt="">
				</div>
				<span>новостройки в этом районе</span>
			</div>
			<div class="novostroiki">
				<?=$arResource['other_raion']['html']?>
			</div>
			<a href="<?=$arResource['other_raion']['link']?>" class="all_items">Смотреть все новостройки в этом районе <span>(<?=$arResource['other_raion']['total']?>)</span></a>
		</div>
		<?endif;?>
	</div>
</div>
<div class="err_modal topmod ajax" id="err_form">
	<form class="ajax" action="/ajax/mail/error_mail.php" method="POST">
		<div class="closmod"></div>
		<div class="wm_tit">
			Сообщить об ошибке
		</div>
		<div class="wm_cont">
			<div class="wm_forwm">
				<div class="wm_row">
					<div class="wm_label">Имя:</div>
					<input type="text" name="name">
					<div class="text_err text_err-name"></div>
				</div>
				<div class="wm_row">
					<div class="wm_label">Тема:</div>
					<input type="text" name="subject">
					<div class="text_err text_err-subject"></div>
				</div>
				<div class="wm_row">
					<div class="wm_label">Телефон:</div>
					<input type="text" name="phone">
					<div class="text_err text_err-phone"></div>
				</div>
				<div class="wm_row">
					<div class="wm_label">Должность:</div>
					<input type="text" name="dolgnost">
					<div class="text_err text_err-dolgnost"></div>
				</div>
				<div class="wm_row">
					<div class="wm_label">Текст:</div>
					<textarea name="msg"></textarea>
					<div class="text_err text_err-msg"></div>
				</div>
				<div class="wm_row3">
					<div class="wmr3_col">
						<div class="wr3_hl">
							<div class="cap4a"><img src="/assets/image/cap4a.jpg"></div>
							<input type="text" class="kapin">
						</div>
						<a href="#" class="kapref">Обновить</a>
					</div>
					<div class="wmr3_col">
						<input type="hidden" name="id" value="[[*id]]">
						<input type="submit" value="Отправить">
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
<div class="err_modal topmod ajax" id="success_send">
	<div class="wm_tit">
		Сообщение отправлено
	</div>
</div>