<?
define('ACTION_AJAX','Y');
include($_SERVER['DOCUMENT_ROOT'].'/ajax/header.php');
$defaultTextError = 'Заполните это поле';

$arResult = $arError = array();
if(trim($_POST['name']) == ''){
	$arError['name'] = $defaultTextError;
}
if(trim($_POST['subject']) == ''){
	$arError['subject'] = $defaultTextError;
}
if(trim($_POST['phone']) == ''){
	$arError['phone'] = $defaultTextError;
}
if(trim($_POST['dolgnost']) == ''){
	$arError['dolgnost'] = $defaultTextError;
}
if(trim($_POST['msg']) == ''){
	$arError['msg'] = $defaultTextError;
}

if(empty($arError)){
	$arResult['STATUS'] = 'OK';
}else{
	$arResult['STATUS'] = 'ERROR';
	$arResult['ERROR'] = $arError;
}
if((int)$_POST['id'] > 0 ){
	$resGK = $modx->getObject('modResource',(int)$_POST['id']);
}

if(empty($arError)){
	$city = $modx->getOption('city', null,'');
	$admin_email = $modx->getOption('error_form_email', null,'');
	$message = 
	'	Имя: '.trim($_POST['name']).'<br>
		Тема: '.trim($_POST['subject']).'<br>
		Телефон: '.trim($_POST['phone']).'<br>
		Должность: '.trim($_POST['dolgnost']).'<br>
		Текст: '.trim($_POST['msg']).'<br>
		<a href="http://'.$_SERVER['HTTP_HOST'].'/manager/?a=resource/update&id='.(int)$resGK->get('id').'">Редактировать ЖК"'.$resGK->get('pagetitle').'"';

	if($resGK){
		$mail = $modx->getService('mail', 'mail.modPHPMailer');
		$mail->setHTML(true);
		$mail->set(modMail::MAIL_SUBJECT, 'Ошибка | г.'.$city.' | ЖК "'.$resGK->get('pagetitle').'"');
		$mail->set(modMail::MAIL_BODY, $message);
		$mail->set(modMail::MAIL_SENDER, 'robot@63rf.ru');
		$mail->set(modMail::MAIL_FROM, 'robot@63rf.ru');
		$mail->set(modMail::MAIL_FROM_NAME, "Твой ЖК");
		foreach(explode(',',$admin_email) as $email){
			$mail->address('to', $email);
		}
		$mail->send();
		$mail->reset();
	}
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($arResult);
die();