tinyMCE.addI18n('ko.modxlink',{
    link_desc:"Insert/edit link"
});