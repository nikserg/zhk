<?
$arFilterProps = array(
	'count_rooms' => array('0','1','2','3','4'),
	'object_srok_sdachi_year' => array('2016','2017','2018'),
);