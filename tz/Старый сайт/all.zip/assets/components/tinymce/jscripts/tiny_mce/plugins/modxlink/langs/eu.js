tinyMCE.addI18n('eu.modxlink',{
    link_desc:"Insert/edit link"
});