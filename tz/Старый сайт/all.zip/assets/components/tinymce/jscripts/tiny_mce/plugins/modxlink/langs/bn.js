tinyMCE.addI18n('bn.modxlink',{
    link_desc:"Insert/edit link"
});