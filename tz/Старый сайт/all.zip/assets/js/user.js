$(document).ready(function() {
    
	submitSearch = function(){
		var data = $('#search_form').serialize(),action = '/ajax/search.php';
		$.get(action,data,function(res){
			$('#gk_count').html(res.totalHTML);
		});
	}
	
	$(".fl_select").click(function(){
		$(this).toggleClass('active');
	});

	$(".menu_btn, .close_menu").click(function(){
		$(".tm_wr").toggleClass("active");
	});
	
	$('.pl_ot,.pl_do').focusout(function(){
		submitSearch();
	});

	$('.fl_ot,.fl_do').keyup(function(){
		submitSearch();
	});

	
	$('.okrug').change(function(){
		if($('.okrug:checked').length > 0){
			$('.chek_raion').removeClass('active');
			$('.chek_raion').find('input').attr('disabled','disabled');
		}
		$('.okrug').each(function(){
			var id = '.okrug_'+$(this).data('okrug_id');
			if($(this).prop("checked")){
				$(id).addClass('active');
				$(id).find('input').removeAttr('disabled');
			}else{
				$(id).removeClass('active');
				$(id).find('input').attr('disabled','disabled');
			}
			$('#raion_count').html('('+$('.chek_raion.active').length+')');
			submitSearch();
		});
		if($('.okrug:checked').length == 0){
			$('.chek_raion').addClass('active');
			$('.chek_raion').find('input').removeAttr('disabled');
		}
	});
	$('#raion_count').html('('+$('.chek_raion.active').length+')');
	
	$('.chek_raion  input,.chek_only').change(function(){
		submitSearch();
	});
	
	$('[name=search]').on('input',function(){
		submitSearch();
		var $this = $(this);
		if($.trim($this.val()) != ''){
			setTimeout(function(){
				$.get('/ajax/text_search.php',{search:$this.val(),asId:'as0'},function(res){
					$('#search_suggestion').show();
					$('#search_suggestion').html('');
					for(var i in res){
						if($.trim(res[i][0]) == "") continue;
						$('#search_suggestion').append('<li class="suggest res_type_'+res[i][2]+'"><a href="'+res[i][1]+'">'+res[i][0]+'</a></li>');
					}
				})
			},250);
		}else{
			$('#search_suggestion').hide();
		}
	});
	$('body').click(function(e){
		if(!$(e.target).hasClass('suggest') && !e.target.form){
			$('#search_suggestion').hide();
		}
	});
	$(document).delegate('.res_type_zastroi a,.res_type_loc a','click',function(){
		var text_search = $(this).html();
		$('[name=search]').val(text_search);
		$('#search_suggestion').html('');
		$('#search_suggestion').hide();
		submitSearch();
		return false;
	});
	
	$(".count_rooms,.srok_sdachi").click(function(){
		$(this).toggleClass('active');
		if($(this).hasClass('active')){
			$(this).find('input').removeAttr('disabled');
		}else{
			$(this).find('input').attr('disabled','disabled');
		}
		submitSearch();
	});

	$(".rm").click(function(){
		$(this).toggleClass('active');
		$("html").toggleClass("ovh");
		$(".right_cont").toggleClass('active');
	});

	$(".price_type").click(function(){
		$(".price_type").removeClass('active');
		$(this).addClass('active');
		$('[name=price_type]').val($(this).data('val'));
	});

	$(".hs_wr").click(function(e){e.stopPropagation();});

	$('.zast_sl').slick({
		infinite: true,
		slidesToShow: 3,
		responsive: [
		{
			breakpoint: 720,
			settings: {
				slidesToShow: 1,
				slidesToScroll: 1,
				infinite: true
			}
		}
		]
	});

	$(".scroll_cont").customScrollbar({
		skin: "default-skin", 
		hScroll: false,
		updateOnWindowResize: true
	});

	$(".rmb_tit.list").click(function(){
		$(this).toggleClass("active");
		$(this).closest(".rm_bl").find('.rmb_wr').toggleClass("active");
	});

	$(".rmb_par.list").click(function(){
		$(this).toggleClass("active");
		$(this).closest(".rmb_it").find('.rmb_wr2').toggleClass("active");
	});

	$(".rmb2_par.list").click(function(){
		$(this).toggleClass("active");
		$(this).closest(".rmb_it2").find('.rmb_wr3').toggleClass("active");
		$(".scroll_cont").customScrollbar("resize", true);
	});

	$(".rmb3_item").click(function(){
		$(this).toggleClass("active");
	});

	$(window).scroll(function () {
		if ($(this).scrollTop() > 0) {
			$('#scroller').fadeIn();
		} else {
			$('#scroller').fadeOut();
		}
	});

	$('#scroller').click(function () {
		$('body,html').animate({
			scrollTop: 0
		}, 400);
		return false;
	});

	$(".gomod").click(function(e){
		e.stopPropagation();
		e.preventDefault();
		$(".topmod").css('display', 'none');
		var mod = $(this).attr("modal");
		$(".topmod[modal="+mod+"]").css('display', 'block');
		if($(".wrap").hasClass("mod")){}
			else {$(".wrap").addClass("mod");}
		$(".wrap.mod").click(function(){
			$(".topmod").css('display', 'none');
			$(this).removeClass("mod");
		});
	});
	$(".topmod").click(function(e){e.stopPropagation();});
	$(".closmod").click(function(){
		$.fancybox.close();
		$('.map_modal').hide();
	});

	$(".full_poisk").click(function(e){
		e.preventDefault();
		$(".tf_cont").toggleClass("active");
		$(".wr_top").toggleClass("active");
		$(".wr_top").toggleClass("noactive");
	});

	$(".sv_tab").click(function(){
		var tab = $(this).attr("tab");
		$(this).toggleClass("active");
		$(".par_row[tab="+tab+"]").toggleClass("active");
	});

	$(".com_read").click(function(e){
		e.preventDefault();
		$(this).toggleClass("active");
		$(this).closest(".comm_block").find(".comm_hide").toggleClass("active");
	});

	$(".jkm_it").click(function(){
		$(".jkm_it").removeClass("active");
		$(this).addClass("active");
	});

	$(".psl").slick({
		infinite: true,
		slidesToShow: 4,
		slidesToScroll: 1,
		responsive: [
		{
			breakpoint: 720,
			settings: {
				slidesToShow: 1,
				slidesToScroll: 1,
				infinite: true
			}
		}
		]
	});


    
    $('.jk_menu').each(function() {
        $(this).find('.jkm_it').each(function(i) {
          $(this).click(function(){
            $(this).addClass('active').siblings().removeClass('active')
              .closest('div.jk_tab').find('.jkt_cont').removeClass('active').eq(i).addClass('active');
          });
        });
    });

	$('[data-formid]').click(function(){
		$.fancybox($(this).data('formid'),{
			closeBtn:false,
			padding:0,
		});
		return false;
	});
	
    $('form.ajax').submit(function(){
        var form = $(this),action = form.attr("action"),data = form.serialize();	
        $.post(action,data,function(res){
            if(res.STATUS=='OK'){
				form.find('[type=text],textarea').removeClass('err');
				form.find('.text_err').html('');
				form.find('[type=text],textarea').val('');
				$.fancybox('#success_send');
			}else{
				form.find('.text_err').html('');
				form.find('[type=text],textarea').removeClass('err');
				for(var i in res.ERROR){
					form.find('[name='+i+']').addClass('err').next().html(res.ERROR[i]);
				}
			}
        });
        return false;
    });
	
	$('a.fancybox,a.zoom').fancybox({
        openEffect:"elastic",
        closeEffect :"elastic",
        nextEffect:"elastic",
        prevEffect:"elastic"
    });
});


jQuery(function($){
   $("#date").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#contact_phone").mask("+7 (999)-999-99-99");
   $("#telContacts").mask("+7 (999)-999-99-99");
   $("#telRequst").mask("+7 (999)-999-99-99");
   $("#tin").mask("99-9999999");
   $("#ssn").mask("999-99-9999");
});

 $(document).ready(function () {
 $('input,textarea').focus(function(){
   $(this).data('placeholder',$(this).attr('placeholder'))
   $(this).attr('placeholder','');
 });
 $('input,textarea').blur(function(){
   $(this).attr('placeholder',$(this).data('placeholder'));
 });
 });

