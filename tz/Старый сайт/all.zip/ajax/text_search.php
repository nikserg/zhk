<?
define('ACTION_AJAX','Y');
include('header.php');
// Определить tpl
$show_suggest = true;
include('prologTextSearch.php');

$arResult = array();
if($strResultId){
	$arResult = explode('##',$strResultId);
	foreach($arResult as &$str){
		$str = explode('||',$str);
		$str[] = 'gk';
	}
}
if($strResultZastroiId){
	$arResultZastroi = explode('##',$strResultZastroiId);
	foreach($arResultZastroi as &$str){
		$str = explode('||',$str);
		$str[] = 'zastroi';
		array_push($arResult,$str);
	}
}
if($strResultLocId){
	$arResultLoc = explode('##',$strResultLocId);
	foreach($arResultLoc as &$str){
		$str = explode('||',$str);
		$str[] = 'loc';
		array_push($arResult,$str);
	}
}

header('Content-Type: application/json; charset='.LANG_CHARSET);
echo json_encode($arResult);
die();