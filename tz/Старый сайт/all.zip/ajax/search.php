<?
define('ACTION_AJAX','Y');
include('header.php');
include('prologFilter.php');

$modx->runSnippet('pdoResources',array(
	'parents' => 43,
	'depth' => '0',
	'limit' => '0',
	'tvFilters' => implode('&&',$tvFilters),
	'tvFiltersAndDelimiter' => '&&',
	'where' => json_encode($where),
	//'showLog' => '1',
));

$arResult['total'] = $modx->getPlaceholder('total');
$arResult['totalHTML'] = $arResult['total'];
if($arResult['total']%10 == 0 || ($arResult['total']%10 >= 5 && $arResult['total']%10<=9) || ($arResult['total']%100>10 && $arResult['total']%100<15)){
	$arResult['totalHTML'] .= ' новостроек';
}
elseif($arResult['total'] %10 == 1){
	$arResult['totalHTML'] .= ' новостройка';
}
else{
	$arResult['totalHTML'] .= ' новостройки';
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($arResult);
die();