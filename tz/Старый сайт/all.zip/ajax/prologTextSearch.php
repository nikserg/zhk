<? if(!defined('ACTION_AJAX') || ACTION_AJAX != 'Y') die();

$query = $_REQUEST['search'];
$search_type = 'gk';
if(preg_match('/^Застройщик /u',$query)){
	$search_type = 'zastroi';
}
if(preg_match('/^Расположение /u',$query)){
	$search_type = 'loc';
}
//Файл advsearchrequest.class.php костыль строка 247
/*
		$searchString = trim(preg_replace('/^Застройщик/u','',$searchString));
		$searchString = trim(preg_replace('/^Расположение/u','',$searchString));
*/
$resultADV = $modx->runSnippet('AdvSearch',array(
	'fields' => 'pagetitle',
	'withFields' => 'pagetitle',
	'hideMenu' => '2',
	'output' => 'ids',
	'searchString' => $_REQUEST['search'],
));
$resultADV = json_decode($resultADV,true);

$tvFilters = $where = array();

$arResultId = array();

if(!empty($resultADV)){
//Застройщик
	$tvFilters[] = 'object_zastoyshik==%';
	//$where[] = array('OR:TVobject_zastoyshik.value:IN'=>$resultADV);
	
//Округ
	$tvFilters[] = 'object_okrug==%';
	//$where[] = array('OR:TVobject_okrug.value:IN'=>$resultADV);
	
//Район
	$tvFilters[] = 'object_raion==%';
	//$where[] = array('OR:TVobject_raion.value:IN'=>$resultADV);

//Улица
	$tvFilters[] = 'object_street==%';
	//$where[] = array('OR:TVobject_street.value:IN'=>$resultADV);
	
	//$where[] = array('OR:id:IN'=>$resultADV);
	
	
	$where[] = array(
		array( 
			array('OR:TVobject_zastoyshik.value:IN'=>$resultADV),
			array('OR:TVobject_okrug.value:IN'=>$resultADV),
			array('OR:TVobject_raion.value:IN'=>$resultADV),
			array('OR:TVobject_street.value:IN'=>$resultADV),
		),
		array(
			'template:='=>9,
		),
		array(
			'OR:id:IN'=>$resultADV,
		),
	);
	//Для поиска новостроек
	$snippetProps = array(
		'parents' => '43',
		'depth' => '0',
		'limit' => '0',
		'tvFilters' => implode('&&',$tvFilters),
		'tvFiltersAndDelimiter' => '&&',
		'where' => json_encode($where),
		'tpl' => '@INLINE[[+id]]',
		'outputSeparator' => ',',
		//'showLog' => '1',
	);
	//Для поиска застройщиков
	$snippetPropsZastroi = array(
		'parents' => '36',
		'depth' => '0',
		'limit' => '0',
		'where' => json_encode(array('id:IN'=>$resultADV)),
		'tpl' => '@INLINE[[+id]]',
		'outputSeparator' => ',',
	);
	//Для поиска улицы или района
	$snippetPropsLoc = array(
		'parents' => '46',
		'depth' => '3',
		'limit' => '0',
		'where' => json_encode(array('id:IN'=>$resultADV)),
		'tpl' => '@INLINE[[+id]]',
		'outputSeparator' => ',',
	);
	
	if($show_suggest){
		$snippetProps['tpl'] = "search_suggestion";
		$snippetProps['includeTVs'] = "object_zastoyshik,object_okrug,object_raion,object_street";
		$snippetProps['outputSeparator'] = "##";
		
		$snippetPropsZastroi['tpl'] = "@INLINE Застройщик [[+pagetitle]]||[[~[[+id]]]]";
		$snippetPropsZastroi['outputSeparator'] = "##";
		
		$snippetPropsLoc['tpl'] = "@INLINE Расположение [[+pagetitle]]||[[~[[+id]]]]";
		$snippetPropsLoc['outputSeparator'] = "##";
	}
	
	$strResultId = '';
	$strResultZastroiId = '';
	$strResultLocId = '';
	/*if($search_type != 'zastroi'){
		$strResultId = $modx->runSnippet('pdoResources',$snippetProps);
	}*/

	if($search_type == 'zastroi'){
		$strResultZastroiId = $modx->runSnippet('pdoResources',$snippetPropsZastroi);
	}elseif($search_type == 'loc'){
		$strResultLocId = $modx->runSnippet('pdoResources',$snippetPropsLoc);
	}else{
		$strResultId = $modx->runSnippet('pdoResources',$snippetProps);
		$strResultZastroiId = $modx->runSnippet('pdoResources',$snippetPropsZastroi);
		$strResultLocId = $modx->runSnippet('pdoResources',$snippetPropsLoc);
	}

	if(!$show_suggest){
		$arResultId = explode(',',$strResultId);
		$arResultZastroiId = explode(',',$strResultZastroiId);
		$arResultLocId = explode(',',$strResultLocId);
	}
}