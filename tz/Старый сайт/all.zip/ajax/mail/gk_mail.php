<?
define('ACTION_AJAX','Y');
include($_SERVER['DOCUMENT_ROOT'].'/ajax/header.php');
$defaultTextError = 'Заполните это поле';

$arResult = $arError = array();
if(trim($_POST['name']) == ''){
	$arError['name'] = $defaultTextError;
}
if(trim($_POST['email']) == ''){
	$arError['email'] = $defaultTextError;
}
if(trim($_POST['phone']) == ''){
	$arError['phone'] = $defaultTextError;
}
if(trim($_POST['msg']) == ''){
	$arError['msg'] = $defaultTextError;
}

if(empty($arError)){
	$arResult['STATUS'] = 'OK';
}else{
	$arResult['STATUS'] = 'ERROR';
	$arResult['ERROR'] = $arError;
}
if((int)$_POST['id'] > 0 ){
	$resGK = $modx->getObject('modResource',(int)$_POST['id']);
}


if(empty($arError)){
	$city = $modx->getOption('city', null,'');
	$admin_email = $modx->getOption('gk_form_email', null,'');
	if($resGK->getTVvalue('gk.ot-l.type') == 1){//Застройщик
		$agent_email = $modx->getObject('modResource',$resGK->getTVvalue('object_zastoyshik'))->getTVvalue('zt.email');
	}else{
		$agent_email = $modx->getObject('modResource',$resGK->getTVvalue('gk.agent'))->getTVvalue('zt.email');
	}
	
	
	$message = 
	'	ЖК <a href="'.$modx->makeURL($resGK->get('id'),'','','http').'">'.$resGK->get('pagetitle').'</a><br>
		Вопрос: '.trim($_POST['msg']).'<br>
		ФИО: '.trim($_POST['name']).'<br>
		Телефон: '.trim($_POST['phone']).'<br>
		E-mail: '.trim($_POST['email']).'<br>
		Портал: <a href="http://'.$_SERVER['HTTP_HOST'].'">твой-жк.рф</a>';

	if($resGK){
		$mail = $modx->getService('mail', 'mail.modPHPMailer');
		//Письмо администратору сайта
		$mail->setHTML(true);
		$mail->set(modMail::MAIL_SUBJECT, 'Вопрос со страницы ЖК "'.$resGK->get('pagetitle').'"| г.'.$city);
		$mail->set(modMail::MAIL_BODY, $message);
		$mail->set(modMail::MAIL_SENDER, 'robot@63rf.ru');
		$mail->set(modMail::MAIL_FROM, 'robot@63rf.ru');
		$mail->set(modMail::MAIL_FROM_NAME, "Твой ЖК");
		$mail->address('to', $admin_email);
		$mail->send();
		$mail->reset();
		//Письмо агенту или застройщику
		$mail->setHTML(true);
		$mail->set(modMail::MAIL_SUBJECT, 'Вопрос с сайта твой-жк.рф');
		$mail->set(modMail::MAIL_BODY, $message);
		$mail->set(modMail::MAIL_SENDER, 'robot@63rf.ru');
		$mail->set(modMail::MAIL_FROM, 'robot@63rf.ru');
		$mail->set(modMail::MAIL_FROM_NAME, "Твой ЖК");
		$mail->address('to', $agent_email);
		$mail->send();
		$mail->reset();
	}
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($arResult);
die();