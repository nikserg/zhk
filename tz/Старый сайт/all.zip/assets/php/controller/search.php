<? if(!defined('IS_TEMPLATE') || IS_TEMPLATE != 'Y') die();


$arCountRooms = array(
	0 => array(
		'title' => 'Студия',
		'value' => '0',
	),
	1 => array(
		'title' => '1',
		'value' => '1',
	),
	2 => array(
		'title' => '2',
		'value' => '2',
	),
	3 => array(
		'title' => '3',
		'value' => '3',
	),
	4 => array(
		'title' => '4',
		'value' => '4',
	),
);
$arYears = array(
	0 => array(
		'title' => 'Сдан',
		'value' => '2000',
	),
	1 => array(
		'title' => '2016',
		'value' => '2016',
	),
	2 => array(
		'title' => '2017',
		'value' => '2017',
	),
	3 => array(
		'title' => '2018',
		'value' => '2018',
	),
	4 => array(
		'title' => '2019+',
		'value' => '3000',
	),
);

$price_type = $_GET['price_type']=='m2'?'m2':'flat';
if((int)$_GET['price_min'] > 0){
	$price_min = (int)$_GET['price_min'];
}
if((int)$_GET['price_max'] > 0){
	$price_max = (int)$_GET['price_max'];
}
if((int)$_GET['area_min'] > 0){
	$area_min = (int)$_GET['area_min'];
}
if((int)$_GET['area_max'] > 0){
	$area_max = (int)$_GET['area_max'];
}
if((int)$_GET['rem'] == 1){
	$input_rem = 'checked';
}
if((int)$_GET['fz'] == 1){
	$input_fz = 'checked';
}
if((int)$_GET['ipot'] == 1){
	$input_ipot = 'checked';
}
if((int)$_GET['mil_ipot'] == 1){
	$input_mil_ipot = 'checked';
}
if((int)$_GET['akcia'] == 1){
	$input_akcia = 'checked';
}

$arOkrug = $modx->runSnippet('pdoMenu',array(
	'parents'=>'46',
	'level'=>'1',
	'showHidden'=>'1',
	'showTree'=>'1',
));
$arChildRaion = $modx->runSnippet('pdoMenu',array(
	'parents'=>'46',
	'level'=>'2',
	'showHidden'=>'1',
	'showTree'=>'1',
));
$arRaion = array();
foreach($arChildRaion as $childRaion){
	foreach($childRaion['children'] as $arItem){
		array_push($arRaion ,$arItem);
	}
}

$site_start = (int)$modx->getOption('site_start', null,'');
$curent_id = (int)$modx->resource->get('id');








